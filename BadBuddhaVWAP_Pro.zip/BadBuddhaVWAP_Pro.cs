#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private BadBuddhaVWAP_Pro[] cacheBadBuddhaVWAP_Pro;

		
		public BadBuddhaVWAP_Pro BadBuddhaVWAP_Pro(bool show05StdDev, bool show1StdDev, bool show15StdDev, bool show2StdDev)
		{
			return BadBuddhaVWAP_Pro(Input, show05StdDev, show1StdDev, show15StdDev, show2StdDev);
		}


		
		public BadBuddhaVWAP_Pro BadBuddhaVWAP_Pro(ISeries<double> input, bool show05StdDev, bool show1StdDev, bool show15StdDev, bool show2StdDev)
		{
			if (cacheBadBuddhaVWAP_Pro != null)
				for (int idx = 0; idx < cacheBadBuddhaVWAP_Pro.Length; idx++)
					if (cacheBadBuddhaVWAP_Pro[idx].Show05StdDev == show05StdDev && cacheBadBuddhaVWAP_Pro[idx].Show1StdDev == show1StdDev && cacheBadBuddhaVWAP_Pro[idx].Show15StdDev == show15StdDev && cacheBadBuddhaVWAP_Pro[idx].Show2StdDev == show2StdDev && cacheBadBuddhaVWAP_Pro[idx].EqualsInput(input))
						return cacheBadBuddhaVWAP_Pro[idx];
			return CacheIndicator<BadBuddhaVWAP_Pro>(new BadBuddhaVWAP_Pro(){ Show05StdDev = show05StdDev, Show1StdDev = show1StdDev, Show15StdDev = show15StdDev, Show2StdDev = show2StdDev }, input, ref cacheBadBuddhaVWAP_Pro);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.BadBuddhaVWAP_Pro BadBuddhaVWAP_Pro(bool show05StdDev, bool show1StdDev, bool show15StdDev, bool show2StdDev)
		{
			return indicator.BadBuddhaVWAP_Pro(Input, show05StdDev, show1StdDev, show15StdDev, show2StdDev);
		}


		
		public Indicators.BadBuddhaVWAP_Pro BadBuddhaVWAP_Pro(ISeries<double> input , bool show05StdDev, bool show1StdDev, bool show15StdDev, bool show2StdDev)
		{
			return indicator.BadBuddhaVWAP_Pro(input, show05StdDev, show1StdDev, show15StdDev, show2StdDev);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.BadBuddhaVWAP_Pro BadBuddhaVWAP_Pro(bool show05StdDev, bool show1StdDev, bool show15StdDev, bool show2StdDev)
		{
			return indicator.BadBuddhaVWAP_Pro(Input, show05StdDev, show1StdDev, show15StdDev, show2StdDev);
		}


		
		public Indicators.BadBuddhaVWAP_Pro BadBuddhaVWAP_Pro(ISeries<double> input , bool show05StdDev, bool show1StdDev, bool show15StdDev, bool show2StdDev)
		{
			return indicator.BadBuddhaVWAP_Pro(input, show05StdDev, show1StdDev, show15StdDev, show2StdDev);
		}

	}
}

#endregion
