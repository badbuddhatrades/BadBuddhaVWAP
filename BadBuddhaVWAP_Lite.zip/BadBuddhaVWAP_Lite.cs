#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private BadBuddhaVWAP_Lite[] cacheBadBuddhaVWAP_Lite;

		
		public BadBuddhaVWAP_Lite BadBuddhaVWAP_Lite()
		{
			return BadBuddhaVWAP_Lite(Input);
		}


		
		public BadBuddhaVWAP_Lite BadBuddhaVWAP_Lite(ISeries<double> input)
		{
			if (cacheBadBuddhaVWAP_Lite != null)
				for (int idx = 0; idx < cacheBadBuddhaVWAP_Lite.Length; idx++)
					if ( cacheBadBuddhaVWAP_Lite[idx].EqualsInput(input))
						return cacheBadBuddhaVWAP_Lite[idx];
			return CacheIndicator<BadBuddhaVWAP_Lite>(new BadBuddhaVWAP_Lite(), input, ref cacheBadBuddhaVWAP_Lite);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.BadBuddhaVWAP_Lite BadBuddhaVWAP_Lite()
		{
			return indicator.BadBuddhaVWAP_Lite(Input);
		}


		
		public Indicators.BadBuddhaVWAP_Lite BadBuddhaVWAP_Lite(ISeries<double> input )
		{
			return indicator.BadBuddhaVWAP_Lite(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.BadBuddhaVWAP_Lite BadBuddhaVWAP_Lite()
		{
			return indicator.BadBuddhaVWAP_Lite(Input);
		}


		
		public Indicators.BadBuddhaVWAP_Lite BadBuddhaVWAP_Lite(ISeries<double> input )
		{
			return indicator.BadBuddhaVWAP_Lite(input);
		}

	}
}

#endregion
